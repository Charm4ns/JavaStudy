package com.lhw.uogBattleship;

public class MediumBattleship extends Battleship{


    public MediumBattleship() {
        super(2,2);
    }

}
