package com.lhw.uogBattleship;

public class SmallBattleship extends Battleship{


    public SmallBattleship() {
        super(1,1);
    }
}
