package com.lhw.uogBattleship;

public class LargeBattleship extends Battleship{


    public LargeBattleship() {
       super(3,3);
    }


}
